const autos = [
  {
    marca: 'Ford',
    modelo: 'Mustang GT',
    year: 2024,
    precio: 52000,
    puertas: 2,
    color: 'Negro',
    transmision: 'Automática',
    img: './imagenes/Ford/FM-Blanco Gris2.png'
  },
  {
    marca: 'Ford',
    modelo: 'Mustang GT',
    year: 2023,
    precio: 75000,
    puertas: 2,
    color: 'Verde',
    transmision: 'Manual',
    img: 'https://www.pngmart.com/files/22/Ford-Mustang-Shelby-GT350-PNG-Photo.png'
  },
  {
    marca: 'Ford',
    modelo: 'Mustang GT',
    year: 2022,
    precio: 70000,
    puertas: 2, 
    color: 'Amarillo',
    transmision: 'Automática',
    img: 'https://www.pngmart.com/files/22/Ford-Mustang-Shelby-GT350-PNG-Isolated-Pic.png'
  },
  {
    marca: 'Chevrolet',
    modelo: 'Camaro SS',
    year: 2023,
    precio: 86900,
    puertas: 2,
    color: 'Blanco',
    transmision: 'Automática',
    img: 'https://www.pngmart.com/files/4/Chevrolet-Camaro-PNG-File.png'
  },
  {
    marca: 'Audi',
    modelo: 'A4',
    year: 2023,
    precio: 45000,
    puertas: 4,
    color: 'Gris',
    transmision: 'Automática',
    img: 'https://www.pngmart.com/files/22/Audi-A4-2019-Transparent-PNG.png'
  },
  {
    marca: 'Audi',
    modelo: 'A4',
    year: 2022,
    precio: 42000,
    puertas: 4,
    color: 'Rojo',
    transmision: 'Manual',
    img: 'https://www.pngmart.com/files/22/Audi-A4-2019-PNG-Clipart.png'
  },
  {
    marca: 'Lamborghini',
    modelo: 'Huracán',
    year: 2023,
    precio: 200000,
    puertas: 2,
    color: 'Amarillo',
    transmision: 'Automática',
    img: 'https://www.pngmart.com/files/10/Lamborghini-Huracan-PNG-Transparent.png'
  },
  {
    marca: 'Lamborghini',
    modelo: 'Huracán',
    year: 2022,
    precio: 190000,
    puertas: 2,
    color: 'Verde',
    transmision: 'Manual',
    img: 'https://www.pngmart.com/files/22/Lamborghini-Huracan-Spyder-Performante-PNG-Isolated-Pic.png'
  },
  {
    marca: 'Mercedes Benz',
    modelo: 'Clase C',
    year: 2023,
    precio: 45900,
    puertas: 4,
    color: 'Gris',
    transmision: 'Automática',
    img: 'https://www.agredasa.es/wp-content/uploads/2016/02/clase-c-coupe.png' // Imagen representativa
  },
  {
    marca: 'Mercedes Benz',
    modelo: 'Clase C',
    year: 2022,
    precio: 44000,
    puertas: 4,
    color: 'Negro',
    transmision: 'Manual',
    img: 'https://vehicle-images.dealerinspire.com/stock-images/chrome/d7f8b833af798861cc2ec6ddbebc3bee.png' // Imagen representativa
  },
  {
    marca: 'Tesla',
    modelo: 'Model 3',
    year: 2023,
    precio: 39000,
    puertas: 4,
    color: 'Blanco',
    transmision: 'Automática',
    img: 'https://d198k1c0ztf4q8.cloudfront.net/eyJidWNrZXQiOiJldnJlbnRpbmdhc3NldHMiLCJrZXkiOiIyMDI1XC8wMlwvMTFcLzI1NzkyNjU4M19UZXNsYU1vZGVsMy1NWTIzLnBuZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MTIwMCwiZml0IjoiY29udGFpbiJ9fX0='
  },
  {
    marca: 'Tesla',
    modelo: 'Model 3',
    year: 2022,
    precio: 37000,
    puertas: 4,
    color: 'Rojo',
    transmision: 'Automática',
    img: 'https://media.drive.com.au/obj/tx_q:80,rs:auto:640:360:1/driveau/upload/cms/uploads/3bf12297-ddc0-5f73-8aa8-70a798650000'
  },
  {
    marca: 'Subaru',
    modelo: 'Impreza',
    year: 2023,
    precio: 30605,
    puertas: 4,
    color: 'Azul',
    transmision: 'Manual',
    img: 'https://www.subarumerida.com.mx/img/wrx/color07.png'
  },
  {
    marca: 'Subaru',
    modelo: 'WRX',
    year: 2022,
    precio: 29000,
    puertas: 4,
    color: 'Negro',
    transmision: 'Automática',
    img: 'https://di-sitebuilder-assets.dealerinspire.com/Subaru/modelLandingPages/WRX/2024/Trims/Base.png'
  },
  {
    marca: 'Chevrolet',
    modelo: 'Corvette',
    year: 2021,
    precio: 60000,
    puertas: 2,
    color: 'Amarillo',
    transmision: 'Automática',
    img: 'https://di-uploads-pod2.dealerinspire.com/carlblackchevynashville/uploads/2018/05/chevrolet_corvette2018_yellow.png'
  },
  {
    marca: 'Lamborghini',
    modelo: 'Aventador',
    year: 2021,
    precio: 380000,
    puertas: 2,
    color: 'Rojo',
    transmision: 'Automática',
    img: 'https://platform.cstatic-images.com/xxlarge/in/v2/stock_photos/41b7b917-8b94-4a5d-856b-42c30213a333/b571fcf8-9116-4bdf-91d1-ec76017b4222.png'
  },
  {
    marca: 'Audi',
    modelo: 'RS7 Sportback',
    year: 2023,
    precio: 121000,
    puertas: 4,
    color: 'Negro',
    transmision: 'Automática',
    img: 'https://cdn-xy.drivek.com/eyJidWNrZXQiOiJkYXRhay1jZG4teHkiLCJrZXkiOiJjb25maWd1cmF0b3ItaW1ncy9jYXJzL2VzL29yaWdpbmFsL0FVREkvUlMtNy1TUE9SVEJBQ0svMzg4ODdfSEFUQ0hCQUNLLTUtRE9PUlMvYXVkaS0yMDIwLXJzNy1zcG9ydGJhY2sucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxMDI0LCJoZWlnaHQiOm51bGwsImZpdCI6ImNvdmVyIn19fQ=='
  },
  {
    marca: 'Subaru',
    modelo: 'BRZ',
    year: 2022,
    precio: 35000,
    puertas: 2,
    color: 'Blanco',
    transmision: 'Manual',
    img: 'https://s7d1.scene7.com/is/image/scom/SZR_K1X_360e_021?$750p$'
  }
];
