//variable de arreglo
let micarrusel = [];
let foto = 0;
let total = 0;

//arreglo para cargar las imagenes de cada foto
micarrusel =[
    { imageurl: "imagenes/Corvette/gallery1.avif", titulo: "Foto 1" },
    { imageurl: "imagenes/Corvette/gallery2.avif", titulo: "Foto 2" },
    { imageurl: "imagenes/Corvette/gallery3.avif", titulo: "Foto 3" },
    { imageurl: "imagenes/Corvette/gallery5.avif", titulo: "Foto 4" },
    { imageurl: "imagenes/Corvette/gallery6.avif", titulo: "Foto 5" }
];

//funcion que permite cambiar las imagenes (interior y siguiente)
let cambiar = function(mas) {
    //almacenar la cantidad total de imagenes
    total = micarrusel.length;
    //almacena la proxima foto
    foto = foto + mas;
    //condicionales para determinar la imagen a presentar
    if(foto > total) {
        foto = 1
    }
    if(foto < 1) {
        //tiene la cantidad total de imagenes
        foto = total;
    }

    //instrucciones que apuntan a cada imagen y titulo que brinda cada logotipo
    //permite apuntar de las fotos con la ruta de cada una
    document.thumb.src = micarrusel[foto - 1].imageurl;
    //asignacion del id titulo
    titulo = document.getElementById('titulo');
    //asignacion del arreglo para referenciar la foto con el titulo
    titulo.innerText = micarrusel[foto-1].titulo;
}