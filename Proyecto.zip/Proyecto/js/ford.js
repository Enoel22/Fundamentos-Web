function c1() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Amarillo.png"
    document.getElementById("color").innerHTML = "Amarillo Solar"
}

function c2() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Azul.png"
    document.getElementById("color").innerHTML = "Azul Atlas"
}

function c3() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Blanco Gris.png"
    document.getElementById("color").innerHTML = "Gris Carbono"
}

function c4() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Blanco Gris2.png"
    document.getElementById("color").innerHTML = "Negro Ocaso"
}

function c5() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Blanco Rojo.png"
    document.getElementById("color").innerHTML = "Rojo Carrera"
}

function c6() {
    document.getElementById("vehiculo").src = "imagenes/Ford/FM-Blanco.png"
    document.getElementById("color").innerHTML = "Blanco Oxford"
}
