'use strict';

window.onload = function() {
    const inputBusqueda = document.getElementById('searchInput');
    inputBusqueda.addEventListener('keypress', validarEnter);
};

function validarEnter(event) {
    if (event.key === 'Enter') {
        searchStores();
    }
}

function searchStores() {
    let searchInput = document.getElementById("searchInput").value.toLowerCase();

    let storeData = {
        "san josé": {
            nombre: "Sucursal San José - Paseo Colón",
            imagen: "imagenes/Sucursales/sucursal1.webp",
            direccion: "Paseo Colón, 200 metros oeste de Torre Mercedes, San José.",
        },
        "heredia": {
            nombre: "Sucursal Heredia - Centro",
            imagen: "imagenes/Sucursales/sucursal2.avif",
            direccion: "100 metros norte del Parque Central de Heredia, frente a la tienda Ekono.",
        },
        "alajuela": {
            nombre: "Sucursal Alajuela - Plaza Real",
            imagen: "imagenes/Sucursales/sucursal3.jpg",
            direccion: "Plaza Real Alajuela, local #12, contiguo a Automercado.",
        },
        "cartago": {
            nombre: "Sucursal Cartago - Terramall",
            imagen: "imagenes/Sucursales/sucursal4.jpg",
            direccion: "Terramall, segundo piso, frente a Tiendas Universal.",
        }
    };

    let coincidencia = Object.keys(storeData).find(key => key.includes(searchInput));
    
    if (!searchInput) {
        swal.fire({
            icon: "error",
            title: "Verificar la entrada de datos",
            confirmButtonText: "Intentar de nuevo",
            confirmButtonColor: "#0063be",
        });
        return;
    }

    let matchedStore = coincidencia ? storeData[coincidencia] : null;

    displayResults(matchedStore);
}

function displayResults(store) {
    let resultsContainer = document.getElementById("pResult");
    resultsContainer.innerHTML = "";

    if (!store) {
        resultsContainer.innerHTML = "<p>No se encontraron sucursales para la ubicación escrita.</p>";
        return;
    }

    let card = document.createElement("div");
    card.className = "card mb-3";
    card.style.maxWidth = "100%";

    card.innerHTML = `
  <div class="row g-0">
    <div class="col-md-4 d-flex align-items-center justify-content-center p-2">
      <img src="${store.imagen}" class="img-fluid rounded shadow-sm" alt="${store.nombre}" style="max-height: 180px; object-fit: cover; width: 100%;">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">${store.nombre}</h5>
        <p class="card-text">${store.direccion}</p>
        <p class="card-text">Visítanos en nuestra sucursal para recibir asesoría sobre seguros, financiamiento o adquirir tu próximo vehículo con nosotros. Estamos para ayudarte.</p>
        <p class="card-text"><small class="text-body-secondary">Última actualización: abril 2025</small></p>
      </div>
    </div>
  </div>
`;


    resultsContainer.appendChild(card);
}
