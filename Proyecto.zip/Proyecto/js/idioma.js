//traducciones en espannol e ingles
const translations = {
    es: {
        optionMenu1: "VEHÍCULOS",
        optionMenu2: "SEGUROS",
        optionMenu3: "ACERCA DE",
        optionMenu4: "FAQ",
        optionMenu5: "CONTACTO",
        COTIZAR: "COTIZAR",
        title1: "PASIÓN POR LA POTENCIA",
        title2: "Una Oportunidad Inteligente",
        h5: "¡Cada vehículo se elige meticulosamente para cumplir con nuestros estándares de calidad y se somete a una inspección exhaustiva! Incluso proporcionamos un informe del historial de CarFax gratuito, para que pueda conducir con total confianza.",
        title3: "Nuestro Inventario: Encuentra tu Auto Ideal",
        p1: "En V8 Garage, contamos con una amplia selección de vehículos para todos los gustos y necesidades. Desde muscle cars de alto rendimiento hasta SUVs familiares y autos compactos, tenemos el modelo perfecto para ti. Filtra por marca, modelo, año, precio y características para encontrar tu próxima máquina. Además, puedes visualizar los autos en diferentes colores y explorar cada detalle con nuestras fichas técnicas completas.",
        title4: "Financiamiento a Tu Medida",
        p2: "Sabemos que comprar un auto es una gran decisión, por eso en V8 Garage te ofrecemos opciones de financiamiento flexibles. Con nuestra calculadora de cuotas, puedes ajustar el monto inicial, el plazo y la tasa de interés para encontrar un plan que se adapte a tu presupuesto. Trabajamos con las mejores entidades financieras para brindarte tasas competitivas y procesos rápidos, sin complicaciones. ¡Haz realidad tu sueño de tener el auto que siempre quisiste!",
        title5: "ESCOGE TU ESTILO",
        conocer: "CONOCER",
        p3: "¡Cada vehículo se elige meticulosamente para cumplir con nuestros estándares de calidad y se somete a una inspección exhaustiva! Incluso proporcionamos un informe del historial de CarFax gratuito, para que pueda conducir con total confianza.",
        title6: "Links Rápidos",
        footer1: "INICIO",
        footer2: "VEHÍCULOS",
        footer3: "SEGUROS",
        footer4: "FAQ",
        footer5: "CONTACTO",
        suscripcion: "Suscríbete para más información",
        suscribirse: "Suscribirse",
    },
    //objeto de idiomas ingles
    en: {
        optionMenu1: "VEHICLES",
        optionMenu2: "INSURANCE",
        optionMenu3: "ABOUT US",
        optionMenu4: "FAQ",
        optionMenu5: "CONTACT",
        COTIZAR: "QUOTE",
        title1: "PASSION FOR POWER",
        title2: "An Intelligent Opportunity",
        h5: "Each vehicle is carefully chosen to meet our quality standards and undergoes thorough inspection! We even provide a free CarFax history report so you can drive with total confidence.",
        title3: "Our Inventory: Find Your Ideal Car",
        p1: "At V8 Garage, we have a wide selection of vehicles for every taste and need. From high-performance muscle cars to family SUVs and compact cars, we have the perfect model for you. Filter by make, model, year, price, and features to find your next machine. Plus, you can view cars in different colors and explore every detail with our complete technical sheets.",
        title4: "Tailored Financing for You",
        p2: "We know that buying a car is a big decision, which is why at V8 Garage we offer flexible financing options. With our payment calculator, you can adjust the down payment, term, and interest rate to find a plan that fits your budget. We work with the best financial institutions to offer competitive rates and fast, hassle-free processes. Make your dream of owning the car you've always wanted a reality!",
        title5: "CHOOSE YOUR STYLE",
        conocer: "LEARN MORE",
        p3: "Each vehicle is carefully selected to meet our quality standards and undergoes a thorough inspection! We even provide a free CarFax history report so you can drive with total confidence.",
        title6: "Quick Links",
        footer1: "HOME",
        footer2: "VEHICLES",
        footer3: "INSURANCE",
        footer4: "FAQ",
        footer5: "CONTACT",
        suscripcion: "Subscribe for more information",
        suscribirse: "Subscribe",
    }
};

//funcion para cambiar el idioma
function changeLanguage() {
    //conversion del lenguaje html
    const lang = document.documentElement.lang === "es" ? "en" : "es";
    document.documentElement.lang = lang;

    //cambiar texto de los elementos con data-translate
    document.querySelectorAll('[data-translate]').forEach(element => {
        //asignacion de atributo data-translate
        const key = element.getAttribute('data-translate');
        //elementos html sean traducidos por las llaves lang - key
        element.textContent = translations[lang][key];
    });
};