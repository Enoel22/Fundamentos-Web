function c1() {
    document.getElementById("vehiculo").src = "imagenes/Lamborghini/huracan_sterrato.webp"
    document.getElementById("color").innerHTML = "Sterrato"
}

function c2() {
    document.getElementById("vehiculo").src = "imagenes/Lamborghini/huracan_sto.webp"
    document.getElementById("color").innerHTML = "STO"
}

function c3() {
    document.getElementById("vehiculo").src = "imagenes/Lamborghini/huracan_tecnica.webp"
    document.getElementById("color").innerHTML = "Técnica"
}


function c4() {
    document.getElementById("vehiculo").src = "imagenes/Lamborghini/huracan_evo_spyder.webp"
    document.getElementById("color").innerHTML = "EVO Spyder"
}

