function c1() {
    document.getElementById("vehiculo").src = "imagenes/Corvette/white.avif"
    document.getElementById("color").innerHTML = "Blanco con Azul Tensión"
}

function c2() {
    document.getElementById("vehiculo").src = "imagenes/Corvette/purple.avif"
    document.getElementById("color").innerHTML = "Purple y Yellow Accent"
}

function c3() {
    document.getElementById("vehiculo").src = "imagenes/Corvette/black.avif"
    document.getElementById("color").innerHTML = "Negro y Naranja Filo"
}


function c4() {
    document.getElementById("vehiculo").src = "imagenes/Corvette/red.avif"
    document.getElementById("color").innerHTML = "Red Accent"
}

