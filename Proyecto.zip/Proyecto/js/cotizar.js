window.addEventListener('DOMContentLoaded', () => {
  const modelSelect = document.getElementById('modelSelect');
  const btnCalcular = document.getElementById('btnCalcular');
  const btnEnviar = document.getElementById('btnEnviar');
  const paymentResult = document.getElementById('paymentResult');
  const alerta = document.getElementById('mensajeAlert');

  // Llenar el selector de autos
  autos.forEach(auto => {
    const option = document.createElement('option');
    option.value = `${auto.marca} ${auto.modelo} ${auto.year}`;
    option.dataset.price = auto.precio;
    option.dataset.autoId = `${auto.marca}-${auto.modelo}-${auto.year}`; // ID personalizado
    option.textContent = `${auto.marca} ${auto.modelo} ${auto.year} - $${auto.precio.toLocaleString()}`;
    modelSelect.appendChild(option);
  });

  btnCalcular.addEventListener('click', () => {
    alerta.innerHTML = '';
    const selectedOption = modelSelect.options[modelSelect.selectedIndex];
    const precio = parseFloat(selectedOption.dataset.price);
    const prima = parseFloat(document.getElementById('prima').value);
    const tasa = parseFloat(document.getElementById('interest').value);
    const años = parseInt(document.getElementById('years').value);
    const email = document.getElementById('user_email').value;

    // Validaciones
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      alerta.innerHTML = `<div class="alert alert-danger">Correo electrónico inválido</div>`;
      return;
    }

    if (isNaN(prima) || prima < 0 || prima >= precio) {
      alerta.innerHTML = `<div class="alert alert-danger">La prima debe ser menor al precio del vehículo</div>`;
      return;
    }

    // Encontrar el objeto auto seleccionado
    const selectedText = selectedOption.value;
    const auto = autos.find(a => `${a.marca} ${a.modelo} ${a.year}` === selectedText);

    if (!auto) {
      alerta.innerHTML = `<div class="alert alert-danger">No se encontró información del vehículo seleccionado.</div>`;
      return;
    }

    // Cálculo de cuota mensual
    const montoFinanciar = precio - prima;
    const interesMensual = tasa / 100 / 12;
    const totalPagos = años * 12;
    const cuotaMensual = montoFinanciar * interesMensual / (1 - Math.pow(1 + interesMensual, -totalPagos));

    // Mostrar resultados con imagen
    const resultadoHTML = `
      <div class="card mb-3 mx-auto" style="max-width: 700px;">
        <div class="row g-0"> 
          <div class="col-md-4 d-flex align-items-center">
            <img src="${auto.img}" class="img-fluid rounded-start" alt="${auto.marca} ${auto.modelo}">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">${auto.marca} ${auto.modelo} ${auto.year}</h5>
              <p class="card-text"><strong>Precio:</strong> $${precio.toLocaleString()}</p>
              <p class="card-text"><strong>Prima:</strong> $${prima.toLocaleString()}</p>
              <p class="card-text"><strong>Tasa de interés:</strong> ${tasa}% anual</p>
              <p class="card-text"><strong>Plazo:</strong> ${años} años</p>
              <p class="card-text"><strong>Cuota mensual estimada:</strong> $${cuotaMensual.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>
    `;

    paymentResult.innerHTML = resultadoHTML;
    paymentResult.classList.remove('d-none');
    btnEnviar.classList.remove('d-none');
  });

  btnEnviar.addEventListener('click', () => {
    const selectedOption = modelSelect.options[modelSelect.selectedIndex];
    const precio = parseFloat(selectedOption.dataset.price);
    const prima = parseFloat(document.getElementById('prima').value);
    const tasa = parseFloat(document.getElementById('interest').value);
    const años = parseInt(document.getElementById('years').value);
    const email = document.getElementById('user_email').value;

    // Datos de la simulación
    const selectedText = selectedOption.value;
    const auto = autos.find(a => `${a.marca} ${a.modelo} ${a.year}` === selectedText);

    const montoFinanciar = precio - prima;
    const interesMensual = tasa / 100 / 12;
    const totalPagos = años * 12;
    const cuotaMensual = montoFinanciar * interesMensual / (1 - Math.pow(1 + interesMensual, -totalPagos));

    // Formato HTML del contenido del correo
    const messageHTML = `
      <h3>Estimado cliente,</h3>
      <p>Gracias por usar nuestro simulador de financiamiento.</p>
      <p>Aquí tienes los resultados de tu simulación:</p>
      <div>
        <h4>Detalles de tu simulación:</h4>
        <ul>
          <li><strong>Vehículo:</strong> ${auto.marca} ${auto.modelo} ${auto.year}</li>
          <li><strong>Precio del vehículo:</strong> $${precio.toLocaleString()}</li>
          <li><strong>Prima / Cuota Inicial:</strong> $${prima.toLocaleString()}</li>
          <li><strong>Tasa de interés anual:</strong> ${tasa}%</li>
          <li><strong>Plazo:</strong> ${años} años</li>
          <li><strong>Cuota mensual estimada:</strong> $${cuotaMensual.toFixed(2)}</li>
        </ul>
        <p>Saludos,</p>
        <p>V8Garage</p>
      </div>
    `;

    // Enviar el correo usando EmailJS
    emailjs.send('service_q4xbr2e', 'template_nma7phh', {
      vehiculo: `${auto.marca} ${auto.modelo} ${auto.year}`,
      precio: `$${precio.toLocaleString()}`,
      prima: `$${prima.toLocaleString()}`,
      tasa: `${tasa}%`,
      plazo: `${años} años`,
      cuota: `$${cuotaMensual.toFixed(2)}`,
      user_email: email
    }, 'HmL6x4JtwNOcORmrn')
    .then(() => {
      alerta.innerHTML = `<div class="alert alert-success">¡Resultado enviado exitosamente al correo!</div>`;
    })
    .catch(error => {
      alerta.innerHTML = `<div class="alert alert-danger">Error al enviar el correo. Intenta nuevamente.</div>`;
      console.error('EmailJS error:', error);
    });    
    
  });
});
