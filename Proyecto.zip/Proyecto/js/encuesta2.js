function evaluarEncuesta () {
    // pregunta 1 y 2
    var pregunta1 = document.getElementById("r1").value;
    var pregunta2 = document.getElementById("r2").value;

    // pregunta 3 - radio
    var respuesta3 = "";
    document.getElementsByName("opinion").forEach(radio => {
        if (radio.checked) {
            respuesta3 = radio.value;
        }
    });

    // pregunta 4 - radio
    var respuesta4 = "";
    document.getElementsByName("opinion2").forEach(radio => {
        if (radio.checked) {
            respuesta4 = radio.value;
        }
    });

    // validación de campos
    if (pregunta1 == "" || pregunta2 == "" || respuesta3 == "" || respuesta4 == "") {
        Swal.fire({
            title: "Atención",
            text: "Por favor complete todos los campos obligatorios.",
            icon: "warning",
        });
    } else {
        // Mensaje basado en checks de aspectos destacados
        let mensaje1 = "";
        const atencion = document.formulario.atencion.checked;
        const calidad = document.formulario.calidad.checked;
        const servicio = document.formulario.servicio.checked;

        if (atencion && calidad && servicio) {
            mensaje1 = "¡Gracias por destacar todos nuestros servicios! En V8Garage nos esforzamos por ofrecer lo mejor.";
        } else if (atencion || calidad || servicio) {
            mensaje1 = "Gracias por sus observaciones, valoramos su opinión y seguiremos mejorando.";
        } else {
            mensaje1 = "Lamentamos no haber cumplido sus expectativas, trabajaremos en ello para mejorar su experiencia.";
        }

        // Mensaje según calificación de atención
        let mensaje3 = "";
        if (respuesta4 == "Buena") {
            mensaje3 = "¡Gracias por calificar positivamente nuestra atención! En V8Garage nos encanta servirle.";
        } else if (respuesta4 == "Regular") {
            mensaje3 = "Agradecemos su sinceridad. Su opinión nos ayuda a seguir mejorando cada día.";
        } else {
            mensaje3 = "Lamentamos que su experiencia no haya sido la mejor. Trabajaremos en nuestras áreas de atención.";
        }

        // Mensaje si volvería
        let mensaje2 = "";
        if (respuesta3 == "Si") {
            mensaje2 = "Nos alegra saber que consideraría volver a V8Garage. ¡Siempre será bienvenido!";
        } else {
            mensaje2 = "Gracias por su visita. Esperamos mejorar para que en el futuro nos vuelva a elegir.";
        }

        // Mensaje emergente con animación
        Swal.fire({
            title: "Encuesta enviada",
            html: "<iframe src='https://embed.lottiefiles.com/animation/123492' width='440' height='380' ></iframe><br><strong>¡Gracias por ayudarnos a mejorar!</strong>",
            showConfirmButton: false,
            timer: 4000
        });

        // Mostrar resultados en pantalla
        document.getElementById("res0").innerHTML = "¡Gracias por completar la encuesta!";
        document.getElementById("res1").innerHTML = mensaje2;
        document.getElementById("res2").innerHTML = mensaje3;
        document.getElementById("res3").innerHTML = mensaje1;
    }
}
